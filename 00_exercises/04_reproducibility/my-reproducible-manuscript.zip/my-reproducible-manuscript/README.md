# my-reproducible manuscript

<!-- badges: start -->
<!-- badges: end -->

Author: Florian Metwaly
Date: 19. January 2025

The goal of my-reproducible-manuscript is to give a template for a reproducible folder structure.


