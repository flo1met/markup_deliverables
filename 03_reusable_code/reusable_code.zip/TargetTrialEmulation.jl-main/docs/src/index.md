# TargetTrialEmulation.jl Documentation

```@meta
CurrentModule = TargetTrialEmulation
DocTestSetup = quote
    using TargetTrialEmulation
end
```

```@docs
seqtrial
TTE
art_censor
```